"use client"

import { Button } from "@/components/ui/button"
import { ArrowLeft, Download, Mail, Phone, Linkedin } from "lucide-react"
import Link from "next/link"

export default function Resume() {
  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <div className="sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <Button variant="ghost" asChild>
            <Link href="/">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Portfolio
            </Link>
          </Button>
          <Button variant="outline" onClick={() => window.print()}>
            <Download className="w-4 h-4 mr-2" />
            Download PDF
          </Button>
        </div>
      </div>

      {/* Resume Content */}
      <div className="max-w-4xl mx-auto px-8 py-12 print:px-12 print:py-8">
        {/* Header */}
        <div className="text-center mb-8 pb-6 border-b-2 border-primary">
          <h1 className="text-4xl font-bold mb-3">Ethen Dhanaraj</h1>
          <div className="flex flex-wrap justify-center gap-4 text-sm text-muted-foreground">
            <span className="flex items-center gap-1">
              <Mail className="w-4 h-4" />
              ethendhanaraj@gmail.com
            </span>
            <span className="flex items-center gap-1">
              <Phone className="w-4 h-4" />
              +1 (209) 237-6970
            </span>
            <span className="flex items-center gap-1">
              <Linkedin className="w-4 h-4" />
              linkedin.com/in/ethen-dhanaraj
            </span>
          </div>
          <p className="text-sm text-muted-foreground mt-2">San Francisco, CA</p>
        </div>

        {/* Education */}
        <section className="mb-8">
          <h2 className="text-2xl font-bold mb-4 pb-2 border-b border-primary/30">EDUCATION</h2>
          <div className="space-y-3">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-bold text-lg">University of California, Santa Cruz</h3>
                <p className="text-muted-foreground">Baskin School of Engineering</p>
                <p className="font-semibold">Bachelor of Science in Electrical Engineering</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Anticipated Minor: Technology Information Management
                </p>
              </div>
              <div className="text-right text-sm">
                <p className="font-semibold">Santa Cruz, CA</p>
                <p className="text-muted-foreground">Expected June 2029</p>
              </div>
            </div>
          </div>
        </section>

        {/* Work Experience */}
        <section className="mb-8">
          <h2 className="text-2xl font-bold mb-4 pb-2 border-b border-primary/30">WORK EXPERIENCE</h2>
          <div className="space-y-6">
            {/* British Swim School */}
            <div>
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h3 className="font-bold text-lg">British Swim School - Swim Instructor</h3>
                </div>
                <div className="text-right text-sm">
                  <p className="font-semibold">Tracy, CA</p>
                  <p className="text-muted-foreground">June 2025 - September 2025</p>
                </div>
              </div>
              <ul className="list-disc list-outside ml-5 space-y-2 text-sm text-muted-foreground">
                <li>
                  Taught the principles of water safety, swimming technique, and the development of swimming skills in
                  both small group (4-6 students) and individual training sessions.
                </li>
                <li>
                  Kept thorough progress tracking and assessment records for more than 75 children, updating management
                  and parents on each student's progress on a monthly basis.
                </li>
                <li>
                  Prevented mishaps and injuries during classes by enforcing stringent safety procedures and providing
                  continuous supervision.
                </li>
              </ul>
            </div>

            {/* Mountain House Sailfish */}
            <div>
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h3 className="font-bold text-lg">Mountain House Sailfish Swim Club - Lifeguard/Swim Instructor</h3>
                </div>
                <div className="text-right text-sm">
                  <p className="font-semibold">Mountain House, CA</p>
                  <p className="text-muted-foreground">June 2023 - August 2024</p>
                </div>
              </div>
              <ul className="list-disc list-outside ml-5 space-y-2 text-sm text-muted-foreground">
                <li>
                  Kept in touch with parents on a frequent basis to update them on their development and professionally
                  and sympathetically handle their worries.
                </li>
                <li>
                  Maintained a close eye on aquatic facilities, proactively identifying hazards and assessing risks to
                  guarantee swimmer safety.
                </li>
                <li>
                  Promptly responded to crises, administering first aid, CPR, and water rescue methods as required.
                </li>
                <li>
                  Showed excellent decision-making and leadership abilities under duress in potentially fatal
                  circumstances.
                </li>
              </ul>
            </div>

            {/* Ushur */}
            <div>
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h3 className="font-bold text-lg">Ushur - Machine Learning Internship</h3>
                </div>
                <div className="text-right text-sm">
                  <p className="font-semibold">Santa Clara, CA</p>
                  <p className="text-muted-foreground">June 2023 - August 2023</p>
                </div>
              </div>
              <ul className="list-disc list-outside ml-5 space-y-2 text-sm text-muted-foreground">
                <li>
                  Obtained practical experience with Customer Experience Automation systems, which intelligently
                  automate complete customer experiences.
                </li>
                <li>
                  Developed proficiency with no-code platforms for workflow automation, natural language processing
                  (NLP), and conversational AI.
                </li>
                <li>
                  Worked with regulated sectors, such as financial services, healthcare, and insurance, to comprehend
                  automation and compliance needs.
                </li>
                <li>
                  Used the AI Studio platform to take part in the training, assessment, and deployment of machine
                  learning models.
                </li>
                <li>
                  Developed AI-powered workflows for practical uses, such as arranging appointments, processing claims,
                  and providing customer service.
                </li>
                <li>
                  Worked with cross-functional teams while implementing enterprise-grade software development
                  techniques.
                </li>
                <li>
                  Used AI technologies to solve difficult enterprise automation problems in highly regulated settings.
                </li>
                <li>
                  Proven capacity to handle sensitive industry data while working efficiently in formal business
                  environments.
                </li>
              </ul>
            </div>
          </div>
        </section>

        {/* Leadership */}
        <section className="mb-8">
          <h2 className="text-2xl font-bold mb-4 pb-2 border-b border-primary/30">LEADERSHIP</h2>
          <div className="space-y-6">
            {/* SkillsUSA */}
            <div>
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h3 className="font-bold text-lg">Mountain House High School SkillsUSA - President</h3>
                </div>
                <div className="text-right text-sm">
                  <p className="font-semibold">Mountain House, CA</p>
                  <p className="text-muted-foreground">April 2022 - May 2025</p>
                </div>
              </div>
              <ul className="list-disc list-outside ml-5 space-y-2 text-sm text-muted-foreground">
                <li>
                  Created the SkillsUSA Attire Rental system and raised $50,000 for chapter support, competition costs,
                  and reasonably priced competition apparel.
                </li>
                <li>
                  In addition to organizing and carrying out strategic events that won Silver and Gold Chapter of
                  Excellence awards, I oversaw a well-organized officer team to guarantee effective chapter operations.
                </li>
                <li>
                  Created a long-lasting chapter infrastructure that will sustain student involvement and competitive
                  performance over time.
                </li>
              </ul>
            </div>

            {/* Interact */}
            <div>
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h3 className="font-bold text-lg">Mountain House High School Interact - President</h3>
                </div>
                <div className="text-right text-sm">
                  <p className="font-semibold">Mountain House, CA</p>
                  <p className="text-muted-foreground">May 2022 - May 2025</p>
                </div>
              </div>
              <ul className="list-disc list-outside ml-5 space-y-2 text-sm text-muted-foreground">
                <li>
                  While working together to create and carry out successful service-oriented projects, I gave the
                  officer team strategic leadership and guidance.
                </li>
                <li>
                  Showed a remarkable dedication to civic duty by devoting more than 100 hours to volunteer work and
                  community service projects.
                </li>
                <li>
                  Through organizing events, facilitating meetings, and working across teams, I developed great
                  organizational and communication abilities.
                </li>
                <li>
                  Established connections with Rotary Club members and community partners to increase chapter members'
                  service options.
                </li>
              </ul>
            </div>
          </div>
        </section>

        {/* Skills */}
        <section className="mb-8">
          <h2 className="text-2xl font-bold mb-4 pb-2 border-b border-primary/30">SKILLS</h2>
          <div className="space-y-3 text-sm">
            <div>
              <span className="font-semibold">Technology: </span>
              <span className="text-muted-foreground">
                Autodesk (Fusion), Microsoft 365 (Excel) & Google Drive Suites, Social Media Marketing (Instagram,
                LinkedIn, Twitter, Facebook), Canva
              </span>
            </div>
            <div>
              <span className="font-semibold">Coding Languages (Intermediate): </span>
              <span className="text-muted-foreground">Python, Java, HTML, CSS</span>
            </div>
          </div>
        </section>
      </div>

      {/* Print Styles */}
      <style jsx global>{`
        @media print {
          body {
            print-color-adjust: exact;
            -webkit-print-color-adjust: exact;
          }
          .print\\:hidden {
            display: none !important;
          }
          nav {
            display: none !important;
          }
          @page {
            margin: 0.5in;
          }
        }
      `}</style>
    </div>
  )
}
