"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Github, Linkedin, Mail, ChevronDown } from "lucide-react"
import Image from "next/image"

export default function Portfolio() {
  const [scrollY, setScrollY] = useState(0)

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY)
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const projects = [
    {
      title: "Electromagnetic Car",
      date: "May 2025",
      description:
        "An innovative project demonstrating electromagnetism and circuit building principles. The car uses a steel bolt wrapped in copper wire powered by two AA batteries and a parallel breadboard circuit to magnetize objects while moving. Successfully picked up fifteen paperclips while driving.",
      features: ["Battery pack routed in parallel", "Steel bolt electromagnet", "Motor connected to gear train"],
      technologies: ["DC Motor", "Breadboard", "Electromagnet"],
      challenges: ["Optimizing field efficiency", "Managing power consumption", "Reducing interference"],
      results: ["Picked up fifteen paperclips", "Ran for over two minutes", "Max speed 5 cm/s"],
      tags: ["Electronics", "Engineering", "Electromagnetism", "Circuit Building"],
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/electrocar-cZfaWQlRzE5LkO3QXyJVM7DnZ0gE2F.png",
      github: "#",
      demo: "#",
    },
    {
      title: "2x2 TV Wall",
      date: "May 2025",
      description:
        "A 2x2 TV wall creating a large, unified display for improved visibility and classroom functionality. Controlled by an Arduino, it synchronizes power, input switching, and brightness, allowing flexible use of individual or combined screens.",
      features: [
        "Four TVs as one large screen",
        "Separate screen use",
        "Integrated audio",
        "Smart control via Arduino",
      ],
      technologies: ["Arduino"],
      challenges: ["Aligning TVs", "Combining inputs"],
      results: ["Fully functional TV wall improving display quality"],
      tags: ["Arduino"],
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/tvwall-aa4STI1zhvYV2TVP5n1YhD00tVc7Fa.png",
      github: "#",
      demo: "#",
    },
  ]

  const experiences = [
    {
      title: "High Voltage System Member",
      organization: "Formula Slug",
      period: "Oct 2025 – Present",
      location: "Santa Cruz, CA",
      description:
        "As an Electrical Team Member, I'm working on high-current cabling and the power electronics box, contributing to the electrical systems that power our competition vehicle. Our team tackles real engineering challenges while developing technical skills and leadership in electric racecar design.",
      technologies: ["Python", "Onshape"],
      logo: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/formula_slug_logo-Pcs9vO56f1mBAM5nTC97lmmir7c8UD.jpeg",
    },
    {
      title: "Electrical Engineering Student",
      organization: "University of California Santa Cruz",
      period: "Sep 2025 – Present",
      location: "Santa Cruz, CA",
      description:
        "Majoring in Electrical Engineering (B.S.) and minoring in Technology and Information Management. Planning to complete my Master's in Electrical and Computer Engineering at UCSC.",
      technologies: ["Python", "Onshape"],
      logo: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/ucsclogo-r5eeSRbobkw6zd6rxR84qZy7wDbk7Y.png",
    },
    {
      title: "Machine Learning Intern",
      organization: "Ushur",
      period: "Jun 2023 – Aug 2023",
      location: "Santa Clara, CA",
      description:
        "As one of only five students selected for this opportunity, I gained hands-on experience with cutting-edge AI and automation technologies at Ushur. I learned about conversational AI, Natural Language Processing, and workflow automation while working with no-code platforms in regulated industries such as healthcare and financial services. The experience exposed me to machine learning model training, AI-powered workflow development, and enterprise-grade software practices while collaborating with teams to solve complex automation challenges.",
      technologies: ["AI", "Machine Learning", "Natural Language Processing"],
      logo: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/ushurlogo-gQfqkHNtDBfLGPxHaYsB81FH7EqOxs.png",
    },
    {
      title: "Engineering & Computer Science Pathway",
      organization: "Mountain House High School",
      period: "Aug 2021 – May 2025",
      location: "Mountain House, CA",
      description:
        "As a dual PLTW pathway student, I completed both the Engineering and Computer Science pathways simultaneously over four years, mastering circuit design, mechanical systems, and programming fundamentals. I balanced two demanding curricula while completing numerous hands-on projects, including my capstone TV Wall system that combined four televisions into one unified display. This interdisciplinary experience provided me with broad technical expertise and the ability to approach complex problems from multiple perspectives.",
      technologies: ["PLTW", "Python", "Fusion", "JavaScript", "Public Speaking"],
      logo: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/mhhslogo-WMPQXtSqgj5KLSWucOXwSS3rgRPCNv.png",
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <header className="fixed top-0 right-0 z-50 p-6">
        <a href="#" className="block hover:opacity-80 transition-opacity">
          <Image src="/icon.png" alt="ED Logo" width={60} height={60} className="object-contain" />
        </a>
      </header>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center px-4 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-950 via-black to-blue-900 animate-gradient" />

        {/* Animated grid pattern */}
        <div
          className="absolute inset-0 opacity-20"
          style={{
            transform: `translateY(${scrollY * 0.5}px)`,
            backgroundImage: "radial-gradient(circle at 2px 2px, rgb(59, 130, 246) 1px, transparent 0)",
            backgroundSize: "40px 40px",
          }}
        />

        {/* Floating orbs */}
        <div className="absolute top-20 left-20 w-64 h-64 bg-blue-500/20 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl animate-float-delayed" />
        <div
          className="absolute top-1/2 left-1/3 w-48 h-48 bg-cyan-500/15 rounded-full blur-2xl animate-float"
          style={{ animationDelay: "2s" }}
        />

        <div className="relative z-10 max-w-6xl mx-auto w-full">
          <div className="flex flex-col md:flex-row items-center justify-between gap-12">
            {/* Left side - Text content */}
            <div className="flex-1 space-y-8 text-center md:text-left">
              <div className="space-y-4">
                <h1 className="text-5xl md:text-7xl font-bold tracking-tight text-balance text-white">
                  Ethen Dhanaraj
                </h1>
                <p className="text-xl md:text-2xl text-blue-300 font-mono">Electrical Engineering Student</p>
                <p className="text-lg text-blue-100/80 max-w-2xl text-pretty leading-relaxed">
                  First-year at UC Santa Cruz, passionate about circuit design, embedded systems, and renewable energy
                  solutions
                </p>
              </div>

              <div className="flex gap-4 justify-center md:justify-start pt-4">
                <Button size="lg" asChild className="bg-blue-600 hover:bg-blue-700">
                  <a href="/resume" target="_blank" rel="noopener noreferrer">
                    View Resume
                  </a>
                </Button>
              </div>

              <div className="flex gap-6 justify-center md:justify-start pt-8">
                <a
                  href="https://github.com/ethend5"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-300 hover:text-blue-100 transition-colors"
                >
                  <Github className="w-6 h-6" />
                  <span className="sr-only">GitHub</span>
                </a>
                <a
                  href="https://www.linkedin.com/in/ethen-dhanaraj/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-300 hover:text-blue-100 transition-colors"
                >
                  <Linkedin className="w-6 h-6" />
                  <span className="sr-only">LinkedIn</span>
                </a>
                <a
                  href="mailto:ethendhanaraj@gmail.com"
                  className="text-blue-300 hover:text-blue-100 transition-colors"
                >
                  <Mail className="w-6 h-6" />
                  <span className="sr-only">Email</span>
                </a>
              </div>
            </div>

            <div className="flex-shrink-0">
              <div className="relative w-64 h-64 md:w-80 md:h-80 rounded-2xl overflow-hidden border-4 border-blue-500 shadow-2xl shadow-blue-500/50">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/hero-banner.JPG-ruwmuRdW6cU3RdMUNUlkIHtZd69sVm.jpeg"
                  alt="Ethen Dhanaraj"
                  fill
                  className="object-cover object-top"
                  priority
                />
              </div>
            </div>
          </div>
        </div>

        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <ChevronDown className="w-6 h-6 text-blue-300" />
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-24 px-4 bg-muted/30">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-8 text-balance">About Me</h2>
          <div className="space-y-6 text-lg leading-relaxed text-muted-foreground">
            <p>
              Hey! I'm Ethen, a student at the University of California, Santa Cruz studying Electrical Engineering. I'm
              driven by a love for engineering innovation and fascinated by the analytical nature of finance—two fields
              that fuel my curiosity about how systems and patterns work and evolve to progress society.
            </p>
          </div>

          <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              {
                name: "Onshape",
                category: "CAD Software",
                logo: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/onshapelogo-lCHbXiGrvHWEyrilZCwIvUQWKa8ubQ.png",
              },
              {
                name: "Fusion",
                category: "CAD Software",
                logo: "/fusion-logo.svg",
              },
              {
                name: "CSS",
                category: "User Interface",
                logo: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/css3-KjIh4MFm2iQTgmc7JyilPc6cnXAdrM.svg",
              },
              {
                name: "JavaScript",
                category: "Interaction",
                logo: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/javascript-iF08HRvQpbrBFkv8egnc5VsQM15mTR.svg",
              },
              {
                name: "Python",
                category: "Programming",
                logo: "/python-logo.png",
              },
              {
                name: "NodeJS",
                category: "Web Server",
                logo: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/nodejs-YFwhziS0udMGgZwh7xmnujUjfBxPyv.svg",
              },
              {
                name: "React",
                category: "Framework",
                logo: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/react-k4KGY9hLOz8Gfs1xqRP0IdecewcyvI.svg",
              },
              {
                name: "TailwindCSS",
                category: "User Interface",
                logo: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/tailwindcss-9B3QEDAbPyv8lv8UgJ7RTguxsQ3z4t.svg",
              },
            ].map((skill) => (
              <Card key={skill.name} className="p-4 text-center hover:shadow-lg transition-shadow">
                <div className="flex justify-center mb-3">
                  <Image
                    src={skill.logo || "/placeholder.svg"}
                    alt={`${skill.name} logo`}
                    width={48}
                    height={48}
                    className="object-contain"
                  />
                </div>
                <p className="font-semibold">{skill.name}</p>
                <p className="text-sm text-muted-foreground mt-1">{skill.category}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section id="projects" className="py-24 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-12 text-balance">Featured Projects</h2>

          <div className="grid md:grid-cols-2 gap-8">
            {projects.map((project, index) => (
              <Card key={index} className="overflow-hidden group hover:shadow-xl transition-shadow">
                <div className="relative h-64 overflow-hidden">
                  <Image
                    src={project.image || "/placeholder.svg"}
                    alt={project.title}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>

                <div className="p-6 space-y-4">
                  <div className="flex items-start justify-between">
                    <h3 className="text-2xl font-bold text-balance">{project.title}</h3>
                    {project.date && <span className="text-sm text-muted-foreground font-mono">{project.date}</span>}
                  </div>
                  <p className="text-muted-foreground leading-relaxed text-pretty">{project.description}</p>

                  {project.features && (
                    <div className="space-y-2">
                      <h4 className="font-semibold text-sm">Features:</h4>
                      <ul className="text-sm text-muted-foreground space-y-1">
                        {project.features.map((feature, i) => (
                          <li key={i} className="flex items-start gap-2">
                            <span className="text-primary mt-1">•</span>
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {project.challenges && (
                    <div className="space-y-2">
                      <h4 className="font-semibold text-sm">Challenges:</h4>
                      <ul className="text-sm text-muted-foreground space-y-1">
                        {project.challenges.map((challenge, i) => (
                          <li key={i} className="flex items-start gap-2">
                            <span className="text-primary mt-1">•</span>
                            <span>{challenge}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {project.results && (
                    <div className="space-y-2">
                      <h4 className="font-semibold text-sm">Results:</h4>
                      <ul className="text-sm text-muted-foreground space-y-1">
                        {project.results.map((result, i) => (
                          <li key={i} className="flex items-start gap-2">
                            <span className="text-primary mt-1">•</span>
                            <span>{result}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  <div className="flex flex-wrap gap-2">
                    {project.tags.map((tag) => (
                      <span key={tag} className="px-3 py-1 text-sm bg-primary/10 text-primary rounded-full">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </Card>
            ))}
          </div>

          <div className="mt-12 text-center">
            <Button variant="outline" size="lg" asChild>
              <a href="https://github.com/ethend5" target="_blank" rel="noopener noreferrer">
                <Github className="w-5 h-5 mr-2" />
                View More on GitHub
              </a>
            </Button>
          </div>
        </div>
      </section>

      <section id="experience" className="py-24 px-4 bg-muted/30">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-12 text-balance">Experience</h2>

          <div className="relative">
            <div className="flex gap-6 overflow-x-auto pb-4 snap-x snap-mandatory scrollbar-thin scrollbar-thumb-primary scrollbar-track-muted">
              {experiences.map((exp, index) => (
                <Card
                  key={index}
                  className="flex-shrink-0 w-[85vw] md:w-[500px] p-6 hover:shadow-xl transition-shadow snap-start"
                >
                  <div className="space-y-4 h-full flex flex-col">
                    <div className="flex items-center gap-4 pb-4 border-b">
                      <div className="flex-shrink-0 w-16 h-16 relative">
                        <Image
                          src={exp.logo || "/placeholder.svg"}
                          alt={`${exp.organization} logo`}
                          fill
                          className="object-contain"
                        />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-xl font-bold text-balance">{exp.title}</h3>
                        <p className="text-lg text-primary font-semibold">{exp.organization}</p>
                      </div>
                    </div>

                    <div className="text-muted-foreground text-sm">
                      <p className="font-mono">{exp.period}</p>
                      <p>{exp.location}</p>
                    </div>

                    <p className="text-muted-foreground leading-relaxed text-pretty flex-grow">{exp.description}</p>

                    <div className="flex flex-wrap gap-2">
                      {exp.technologies.map((tech) => (
                        <span key={tech} className="px-3 py-1 text-sm bg-blue-900/70 text-blue-100 rounded-full">
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 px-4">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          <h2 className="text-3xl md:text-4xl font-bold text-balance">Let's Connect</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto text-pretty leading-relaxed">
            I'm always excited to collaborate on interesting projects or discuss new opportunities in electrical
            engineering and technology. Feel free to reach out!
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-8">
            <Button size="lg" asChild>
              <a href="mailto:ethendhanaraj@gmail.com">
                <Mail className="w-5 h-5 mr-2" />
                Email Me
              </a>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <a href="https://www.linkedin.com/in/ethen-dhanaraj/" target="_blank" rel="noopener noreferrer">
                <Linkedin className="w-5 h-5 mr-2" />
                Connect on LinkedIn
              </a>
            </Button>
          </div>

          <div className="pt-12 space-y-4">
            <div className="flex flex-wrap gap-6 justify-center text-sm text-muted-foreground">
              <a
                href="https://github.com/ethend5"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-foreground transition-colors flex items-center gap-2"
              >
                <Github className="w-4 h-4" />
                github.com/ethend5
              </a>
              <a
                href="https://www.linkedin.com/in/ethen-dhanaraj/"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-foreground transition-colors flex items-center gap-2"
              >
                <Linkedin className="w-4 h-4" />
                linkedin.com/in/ethen-dhanaraj
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 border-t">
        <div className="max-w-6xl mx-auto text-center text-sm text-muted-foreground">
          <p>© 2025 Ethen Dhanaraj. Built with Next.js and deployed on Vercel.</p>
        </div>
      </footer>
    </div>
  )
}
